</div>
	<div id="footer">
		<div class="container">
			<div class="copy text-center">
               Copyright <?php echo date("Y") ?> <a href='https://ctiplus.pl'>ctiplus.pl</a>
			</div>
		</div>
    </div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://code.jquery.com/jquery.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="js/custom.js"></script>
  </body>
</html>