<?php namespace classes\Photo;
require_once dirname(dirname(dirname(__FILE__))).'/config/config.php';

class PhotosFactory{
    
}