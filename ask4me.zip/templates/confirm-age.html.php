<?php include_once dirname(__FILE__).'/includes/subheader.html.php';?>
<?php include_once dirname(__FILE__).'/includes/top_menu.html.php';?>

<div class="index age content">
    <div class="top-image" style="background:url(img/top-image.jpg) no-repeat center center;">
        <div class="container">
            <h1>This site contains adult content</h1>
            
            <div class="wrapper">
                <div class="box center white-txt">
                    <p class="xl-txt">Lorem ipsum dolor sit amet sapien varius nunc vel dolor. Vivamus orci et magnis dis parturient montes, nascetur ridiculus mus. Nam eu mollis tincidunt, risus in turpis at adipiscing elit. Proin justo. Ut sodales eu, iaculis et, scelerisque odio id leo eu sem id lorem. Donec elementum.</p>
                     <p class="xl-txt">Curae, Mauris vitae metus facilisis nunc, rhoncus laoreet iaculis pede id lacus. Nulla et ultrices posuere cubilia Curae, Sed molestie, neque at consequat ipsum eget wisi.</p>
                    
                    <a href="index.php" class="button med-prim-bg">I am 18+ years old</a>
                    <a href="http://google.com" class="button med-prim-bg">Exit</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$('body').addClass('confirm-age');
</script>

<?php include_once dirname(__FILE__).'/includes/footer.html.php';?>