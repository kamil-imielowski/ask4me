<?php include_once dirname(__FILE__).'/includes/subheader.html.php';?>
<?php include_once dirname(__FILE__).'/includes/top_menu.html.php';?>

<div class="cms about-profiles content">
    <div class="container section">
    
        <h3>Learn more about profiles</h3>
        
        <div class="cms-content">
            <!--tutaj treści dodane przez panel administracyjny-->
        </div>
            
        <a href="profile-creation.php" class="button empty med-prim-br">Create your profile</a>
        
    </div>
</div>

    
<?php include_once dirname(__FILE__).'/includes/footer.html.php';?>