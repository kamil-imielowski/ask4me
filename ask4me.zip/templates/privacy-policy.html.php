<?php include_once dirname(__FILE__).'/includes/subheader.html.php';?>
<?php include_once dirname(__FILE__).'/includes/top_menu.html.php';?>

<div class="cms privacy content">
    <div class="container section">
    
        <h3>Privacy policy</h3>
        
        <div class="cms-content">
            <?php echo $cms->getContent(); ?>
        </div>
        
    </div>
</div>

    
<?php include_once dirname(__FILE__).'/includes/footer.html.php';?>