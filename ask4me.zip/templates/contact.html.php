<?php include_once dirname(__FILE__).'/includes/subheader.html.php';?>
<?php include_once dirname(__FILE__).'/includes/top_menu.html.php';?>

<div class="contact content">
    <div class="container section">
    
        <h3>Contact us</h3>
        
        <p class="xl-txt">Lorem ipsum dolor sit amet sapien varius nunc vel dolor</p>
        
        <form>
            <input type="email" placeholder="Your e-mail address*" required>
            <input type="ttext" placeholder="Subject">
            <textarea placeholder="Your message*" required></textarea>
            <input type="button" class="button empty med-prim-br" value="Send">
        </form>
        
    </div>
</div>

    
<?php include_once dirname(__FILE__).'/includes/footer.html.php';?>