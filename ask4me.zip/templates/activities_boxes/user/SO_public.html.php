<div class="activity public">
    <div class="top">
        <h6>Lorem ipsum dolor</h6>
        <p class="xs-txt">Public webcam broadcast</p>
    </div>
    <a href="model.php" class="user">
        <div class="avatar bg-img circle" style="background:url('img/profile.jpg') center center no-repeat;"></div>
        <span>Username,</span>
        <span class="lt-txt">Country</span>
    </a>
    <div class="when">
        <p class="date"><strong>Starting soon</strong></p>
        <a href="broadcast.php" class="button med-prim-bg">Enter now</a>
    </div>
    <div class="icons">
        <a href="#" data-toggle="modal" data-target="#unsubscribe" ><i class='fa fa-close'></i><span>unsubscribe</span></a>
    </div>
</div>