<div class="activity person">
    <div class="top">
        <h6>In person service</h6>
    </div>
    <a href="model.php" class="user">
        <div class="avatar bg-img circle" style="background:url('img/profile.jpg') center center no-repeat;"></div>
        <span>Username,</span>
        <span class="lt-txt">Country</span>
    </a>
    <div class="when">
        <p class="date"><strong>31.07.17</strong></p>
        <p class="time"><strong>20:00</strong></p>
    </div>
    <div class="icons">
        <a href="#" onClick="tab('edit', this);"><i class='fa fa-pencil'></i><span>edit</span></a>
        <a href="#" data-toggle="modal" data-target="#cancel" ><i class='fa fa-close'></i><span>cancel</span></a>
    </div>
</div>