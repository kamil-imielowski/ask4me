//var socket = io("websocket.ask-for.me");

$(function () {

    //testowa funkcja (test w root/testWSS.php [przycisk asd])
    //socket.on('tip', function(msg){
    //    console.log(msg);
    //});

});
  