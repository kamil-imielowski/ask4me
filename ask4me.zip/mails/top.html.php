<?php require_once dirname(dirname(__FILE__)).'/functions/urlProtocolAndName.php'; ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>		
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />		
        <title><?php $translate->getString('mailTitle') ?></title>		
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>	
    </head>	
    <body style="margin: 0; padding: 0;">		
        <table  align="center" border="0" cellpadding="0" cellspacing="0" width="600" style="border-collapse: collapse; font-family:Arial, Helvetica, sans-serif; color:#fff; background:url(\'http://present4u.tv/img/background.jpg\') #640d14 repeat center center fixed">			
            <tr>				
                <td bgcolor="#640d14" style="padding: 0 20px; border-bottom:10px solid #212121;">				
                    <a href="<?php echo siteURL()?>" target="_blank" >						
                        <img src="<?php echo siteURL()?>/img/logo.png" alt="logo" height="100" style="display: block;" />
                    </a>				
                </td>			
            </tr>			