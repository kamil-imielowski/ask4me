            <tr>				
                <td bgcolor="#212121" style="padding: 15px 20px 15px 20px; color:#fff;border-top:5px solid #640d14;">					
                    <span style="font-size:11px;">Copyright by ask-for.me <?php echo date("Y") ?></span>			
                </td>			
            <tr>		
        </table>	
    </body>
</html>