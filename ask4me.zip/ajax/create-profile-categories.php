<div class="section categories animated fadeIn">
    <h4 class="dashboard-heading">Categories and services</h4>
    
    <div class="form">
        
        <form>
            <h6 class="dashboard-heading">Choose categories that fit your profile:</h6>
        
            <div class="columns">

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox1">
                    <label for="checkbox1">
                        Anal
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox2">
                    <label for="checkbox2">
                        Blonde
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox3">
                    <label for="checkbox3">
                        Mature
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox4">
                    <label for="checkbox4">
                        Teens 18+
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox5">
                    <label for="checkbox5">
                        Asian
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox6">
                    <label for="checkbox6">
                        Curvy
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox7">
                    <label for="checkbox7">
                        Lesbian
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox8">
                    <label for="checkbox8">
                        Housewives
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox9">
                    <label for="checkbox9">
                        Babes
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox10">
                    <label for="checkbox10">
                        Brunette
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox11">
                    <label for="checkbox11">
                        Redhead
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox12">
                    <label for="checkbox12">
                        Toys
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox13">
                    <label for="checkbox13">
                        Ebony
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox14">
                    <label for="checkbox14">
                        Petite
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox15">
                    <label for="checkbox15">
                        Foot
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox16">
                    <label for="checkbox16">
                        Pornstar
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox17">
                    <label for="checkbox17">
                        Small tits
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox18">
                    <label for="checkbox18">
                        College girls
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox19">
                    <label for="checkbox19">
                        Shaved
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox20">
                    <label for="checkbox20">
                        BBW
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox21">
                    <label for="checkbox21">
                        White girls
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox22">
                    <label for="checkbox22">
                        Muscle
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox23">
                    <label for="checkbox23">
                        Smoking
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox24">
                    <label for="checkbox24">
                        Pregnant
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox25">
                    <label for="checkbox25">
                        Big tits
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox26">
                    <label for="checkbox25">
                        Hairy
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox25">
                    <label for="checkbox26">
                        Squirt
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox27">
                    <label for="checkbox27">
                        Big butt
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox28">
                    <label for="checkbox28">
                        Latina
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox29">
                    <label for="checkbox29">
                        Granny
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox30">
                    <label for="checkbox30">
                        Group sex
                    </label>
                </div>

                <div class="form-group checkbox">
                    <input type="checkbox" id="checkbox31">
                    <label for="checkbox31">
                        Transgender
                    </label>
                </div>

            </div>

            <h6 class="dashboard-heading">What service are you going to provide?</h6>

            <div class="radios">

                <div class="form-group radio inline">
                    <input type="radio" name="radio1" value="option1" id="radio1" checked>
                    <label for="radio1">
                        Escort only
                    </label>
                </div>

                <div class="form-group radio inline">
                    <input type="radio" name="radio1" value="option2" id="radio2">
                    <label for="radio2">
                        Webcam only (required basic membership)
                    </label>
                </div>

                <div class="form-group radio inline">
                    <input type="radio" name="radio1" value="option3" id="radio3">
                    <label for="radio3">
                        Both (required basic membership)
                    </label>
                </div>

            </div>
            
            <div class="escort-info"><!--tylko do escort services i both-->
                <h6 class="dashboard-heading">Add locations where you are willing to provide escort services:</h6>
                
                <div class="form-group multiple">
                    <div class="select">
                        <select>
                            <option value="0" selected disabled>Choose country</option>
                            <option value="1">Country 1</option>
                            <option value="2">Country 2</option>
                            <option value="3">Country 3</option>
                         </select>
                    </div>
                    <input type="text" placeholder="City or region">
                </div>
                
                <a href="#" class="add-activity"><i class="fa fa-plus lt-txt"></i><span>Add another location</span></a>
                
            </div>
            
            <a href="#" class="med-prim-bg button">Next step</a>
            
        </form>
        
    </div>
</div>
