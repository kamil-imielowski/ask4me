<div class="section code animated fadeIn">
    <h4 class="dashboard-heading">Enter code</h4>
    
    <p>Here you can enter the code provided by your customer to receive payment for escort services:</p>
    
    <div class="form">
        
        <form>
            
            <div class="form-group">
                <label>Enter code:</label>
                <input type="text" placeholder="Enter code">
            </div>
            
            <input type="submit" class="button med-prim-bg" value="Submit" />
            
        </form>
        
    </div>
</div>	