<div class="feedback animated fadeIn">
    
    <div class="summary">
        <div class="positive">
            <p>
                <i class='material-icons'>thumb_up</i>
                <strong>Positive feedback:</strong><span>80%</span>
            </p>
        </div>
        <div class="negative">
            <p>
                <i class='material-icons'>thumb_down</i>
                <strong>Negative feedback:</strong><span>20%</span>
            </p>
        </div>
    </div>
    
    <div class="item positive">
        <div class="from">
            <label>From:</label>
            <a href="user.php">username</a>
        </div>
        <p><i>Nam sodales elementum dolor non semper. Donec ac risus risus. Proin lacus nulla, bibendum aliquam nibh vel, viverra aliquam arcu. Ut eu tempus tellus. Maecenas euismod bibendum nisi, eget mollis urna sagittis sed. Duis molestie, metus ac facilisis pretium.</i></p>
    </div>
    
    <div class="item positive">
        <div class="from">
            <label>From:</label>
            <a href="user.php">username</a>
        </div>
        <p><i>Nam sodales elementum dolor non semper. Donec ac risus risus. Proin lacus nulla, bibendum aliquam nibh vel, viverra aliquam arcu. Ut eu tempus tellus. Maecenas euismod bibendum nisi, eget mollis urna sagittis sed. Duis molestie, metus ac facilisis pretium.</i></p>
    </div>
    
    <div class="item positive">
        <div class="from">
            <label>From:</label>
            <a href="user.php">username</a>
        </div>
        <p><i>Nam sodales elementum dolor non semper. Donec ac risus risus. Proin lacus nulla, bibendum aliquam nibh vel, viverra aliquam arcu. Ut eu tempus tellus. Maecenas euismod bibendum nisi, eget mollis urna sagittis sed. Duis molestie, metus ac facilisis pretium.</i></p>
    </div>
    
    <div class="item negative">
        <div class="from">
            <label>From:</label>
            <a href="user.php">username</a>
        </div>
        <p><i>Nam sodales elementum dolor non semper. Donec ac risus risus. Proin lacus nulla, bibendum aliquam nibh vel, viverra aliquam arcu. Ut eu tempus tellus. Maecenas euismod bibendum nisi, eget mollis urna sagittis sed. Duis molestie, metus ac facilisis pretium.</i></p>
    </div>
    
    <div class="item positive">
        <div class="from">
            <label>From:</label>
            <a href="user.php">username</a>
        </div>
        <p><i>Nam sodales elementum dolor non semper. Donec ac risus risus. Proin lacus nulla, bibendum aliquam nibh vel, viverra aliquam arcu. Ut eu tempus tellus. Maecenas euismod bibendum nisi, eget mollis urna sagittis sed. Duis molestie, metus ac facilisis pretium.</i></p>
    </div>
    
    
</div>
