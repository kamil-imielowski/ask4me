<div class="section raports animated fadeIn">
    <h4 class="dashboard-heading">Raports</h4>
    
    <div class="form">
        
        <form>
            
            <div class="form-group">
                <label>Choose a raport type:</label>
                <div class="select">
                    <select>
                        <option value="0" selected disabled>Raport type</option>
                        <option value="1">Sekcja do ustalenia</option>
                     </select>
                </div>
            </div>
            
        </form>
        
    </div>
</div>	